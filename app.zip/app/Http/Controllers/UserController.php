<?php

namespace App\Http\Controllers;

use App\Models\Funciones;
use App\User;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function get($id)
    {
        $user=Auth::user();

        if (! $user) {
            return json_encode([]);
        }
        return json_encode($user);
    }

    /**
     * @return \Illuminate\Http\RedirectResponse|string
     */
    public function getAll()
    {
        /**
         * @var User $user
         */
        $user=Auth::user();
        if ($user->can('getAll', User::class)) {
            $usuario = User::all();
            if ($usuario==null) {
                return redirect()->route('/')->with("alert", Funciones::getAlert("danger", "Error al intentar buscar", "Ha ocurrido un problema obteniendo los resultados."));
            } else {
                return redirect()->route('/')->with("alert", Funciones::getAlert("danger", "Error al intentar buscar", "Ha ocurrido un problema obteniendo los resultados."));
            }
        }

        return redirect()->route('/')->with("alert", Funciones::getAlert("danger", "Error al intentar editar", "Operación errónea. Usuario no autorizado."));
    }
}
